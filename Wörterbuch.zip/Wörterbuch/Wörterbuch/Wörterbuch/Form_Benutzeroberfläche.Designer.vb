﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Benutzeroberfläche
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_Hinzufügen = New System.Windows.Forms.Button()
        Me.btn_AlleAnzeigen = New System.Windows.Forms.Button()
        Me.tb_Deutsch = New System.Windows.Forms.TextBox()
        Me.tb_Suchen = New System.Windows.Forms.TextBox()
        Me.btn_Suche = New System.Windows.Forms.Button()
        Me.tb_Wörter = New System.Windows.Forms.TextBox()
        Me.tb_Informationen = New System.Windows.Forms.TextBox()
        Me.label_Wörter = New System.Windows.Forms.Label()
        Me.label_Informationen = New System.Windows.Forms.Label()
        Me.rb_Englisch = New System.Windows.Forms.RadioButton()
        Me.rb_Deutsch = New System.Windows.Forms.RadioButton()
        Me.label_Deutsch = New System.Windows.Forms.Label()
        Me.label_Englisch = New System.Windows.Forms.Label()
        Me.label_WortartDeutsch = New System.Windows.Forms.Label()
        Me.tb_Englisch = New System.Windows.Forms.TextBox()
        Me.tb_WortartDeutsch = New System.Windows.Forms.TextBox()
        Me.label_BeschreibungDeutsch = New System.Windows.Forms.Label()
        Me.tb_BeschreibungDeutsch = New System.Windows.Forms.TextBox()
        Me.label_AnzahlWörter = New System.Windows.Forms.Label()
        Me.label_WortartEnglisch = New System.Windows.Forms.Label()
        Me.label_BeschreibungEnglisch = New System.Windows.Forms.Label()
        Me.tb_WortartEnglisch = New System.Windows.Forms.TextBox()
        Me.tb_BeschreibungEnglisch = New System.Windows.Forms.TextBox()
        Me.tb_AnzahlWörter = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn_Hinzufügen
        '
        Me.btn_Hinzufügen.BackColor = System.Drawing.SystemColors.HighlightText
        Me.btn_Hinzufügen.Location = New System.Drawing.Point(527, 85)
        Me.btn_Hinzufügen.Name = "btn_Hinzufügen"
        Me.btn_Hinzufügen.Size = New System.Drawing.Size(89, 48)
        Me.btn_Hinzufügen.TabIndex = 0
        Me.btn_Hinzufügen.Text = "Hinzufügen"
        Me.btn_Hinzufügen.UseVisualStyleBackColor = False
        '
        'btn_AlleAnzeigen
        '
        Me.btn_AlleAnzeigen.BackColor = System.Drawing.SystemColors.HighlightText
        Me.btn_AlleAnzeigen.Location = New System.Drawing.Point(12, 33)
        Me.btn_AlleAnzeigen.Name = "btn_AlleAnzeigen"
        Me.btn_AlleAnzeigen.Size = New System.Drawing.Size(130, 22)
        Me.btn_AlleAnzeigen.TabIndex = 1
        Me.btn_AlleAnzeigen.Text = "Alle anzeigen"
        Me.btn_AlleAnzeigen.UseVisualStyleBackColor = False
        '
        'tb_Deutsch
        '
        Me.tb_Deutsch.Location = New System.Drawing.Point(133, 65)
        Me.tb_Deutsch.Name = "tb_Deutsch"
        Me.tb_Deutsch.Size = New System.Drawing.Size(108, 20)
        Me.tb_Deutsch.TabIndex = 2
        '
        'tb_Suchen
        '
        Me.tb_Suchen.Location = New System.Drawing.Point(496, 9)
        Me.tb_Suchen.Name = "tb_Suchen"
        Me.tb_Suchen.Size = New System.Drawing.Size(120, 20)
        Me.tb_Suchen.TabIndex = 3
        '
        'btn_Suche
        '
        Me.btn_Suche.BackColor = System.Drawing.SystemColors.HighlightText
        Me.btn_Suche.Location = New System.Drawing.Point(415, 7)
        Me.btn_Suche.Name = "btn_Suche"
        Me.btn_Suche.Size = New System.Drawing.Size(75, 23)
        Me.btn_Suche.TabIndex = 4
        Me.btn_Suche.Text = "Suche"
        Me.btn_Suche.UseVisualStyleBackColor = False
        '
        'tb_Wörter
        '
        Me.tb_Wörter.Location = New System.Drawing.Point(12, 178)
        Me.tb_Wörter.Multiline = True
        Me.tb_Wörter.Name = "tb_Wörter"
        Me.tb_Wörter.ReadOnly = True
        Me.tb_Wörter.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.tb_Wörter.Size = New System.Drawing.Size(299, 335)
        Me.tb_Wörter.TabIndex = 6
        '
        'tb_Informationen
        '
        Me.tb_Informationen.Location = New System.Drawing.Point(317, 178)
        Me.tb_Informationen.Multiline = True
        Me.tb_Informationen.Name = "tb_Informationen"
        Me.tb_Informationen.ReadOnly = True
        Me.tb_Informationen.Size = New System.Drawing.Size(299, 335)
        Me.tb_Informationen.TabIndex = 7
        '
        'label_Wörter
        '
        Me.label_Wörter.AutoSize = True
        Me.label_Wörter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_Wörter.Location = New System.Drawing.Point(9, 159)
        Me.label_Wörter.Name = "label_Wörter"
        Me.label_Wörter.Size = New System.Drawing.Size(51, 16)
        Me.label_Wörter.TabIndex = 8
        Me.label_Wörter.Text = "Wörter:"
        '
        'label_Informationen
        '
        Me.label_Informationen.AutoSize = True
        Me.label_Informationen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_Informationen.Location = New System.Drawing.Point(314, 159)
        Me.label_Informationen.Name = "label_Informationen"
        Me.label_Informationen.Size = New System.Drawing.Size(91, 16)
        Me.label_Informationen.TabIndex = 9
        Me.label_Informationen.Text = "Informationen:"
        '
        'rb_Englisch
        '
        Me.rb_Englisch.AutoSize = True
        Me.rb_Englisch.Location = New System.Drawing.Point(12, 10)
        Me.rb_Englisch.Name = "rb_Englisch"
        Me.rb_Englisch.Size = New System.Drawing.Size(65, 17)
        Me.rb_Englisch.TabIndex = 10
        Me.rb_Englisch.TabStop = True
        Me.rb_Englisch.Text = "Englisch"
        Me.rb_Englisch.UseVisualStyleBackColor = True
        '
        'rb_Deutsch
        '
        Me.rb_Deutsch.AutoSize = True
        Me.rb_Deutsch.Checked = True
        Me.rb_Deutsch.Location = New System.Drawing.Point(77, 10)
        Me.rb_Deutsch.Name = "rb_Deutsch"
        Me.rb_Deutsch.Size = New System.Drawing.Size(65, 17)
        Me.rb_Deutsch.TabIndex = 11
        Me.rb_Deutsch.TabStop = True
        Me.rb_Deutsch.Text = "Deutsch"
        Me.rb_Deutsch.UseVisualStyleBackColor = True
        '
        'label_Deutsch
        '
        Me.label_Deutsch.AutoSize = True
        Me.label_Deutsch.Location = New System.Drawing.Point(12, 68)
        Me.label_Deutsch.Name = "label_Deutsch"
        Me.label_Deutsch.Size = New System.Drawing.Size(47, 13)
        Me.label_Deutsch.TabIndex = 12
        Me.label_Deutsch.Text = "Deutsch"
        '
        'label_Englisch
        '
        Me.label_Englisch.AutoSize = True
        Me.label_Englisch.Location = New System.Drawing.Point(249, 68)
        Me.label_Englisch.Name = "label_Englisch"
        Me.label_Englisch.Size = New System.Drawing.Size(47, 13)
        Me.label_Englisch.TabIndex = 13
        Me.label_Englisch.Text = "Englisch"
        '
        'label_WortartDeutsch
        '
        Me.label_WortartDeutsch.AutoSize = True
        Me.label_WortartDeutsch.Location = New System.Drawing.Point(12, 91)
        Me.label_WortartDeutsch.Name = "label_WortartDeutsch"
        Me.label_WortartDeutsch.Size = New System.Drawing.Size(85, 13)
        Me.label_WortartDeutsch.TabIndex = 14
        Me.label_WortartDeutsch.Text = "Wortart Deutsch"
        '
        'tb_Englisch
        '
        Me.tb_Englisch.Location = New System.Drawing.Point(370, 65)
        Me.tb_Englisch.Name = "tb_Englisch"
        Me.tb_Englisch.Size = New System.Drawing.Size(108, 20)
        Me.tb_Englisch.TabIndex = 15
        '
        'tb_WortartDeutsch
        '
        Me.tb_WortartDeutsch.Location = New System.Drawing.Point(133, 88)
        Me.tb_WortartDeutsch.Name = "tb_WortartDeutsch"
        Me.tb_WortartDeutsch.Size = New System.Drawing.Size(108, 20)
        Me.tb_WortartDeutsch.TabIndex = 16
        '
        'label_BeschreibungDeutsch
        '
        Me.label_BeschreibungDeutsch.AutoSize = True
        Me.label_BeschreibungDeutsch.Location = New System.Drawing.Point(12, 116)
        Me.label_BeschreibungDeutsch.Name = "label_BeschreibungDeutsch"
        Me.label_BeschreibungDeutsch.Size = New System.Drawing.Size(115, 13)
        Me.label_BeschreibungDeutsch.TabIndex = 17
        Me.label_BeschreibungDeutsch.Text = "Beschreibung Deutsch"
        '
        'tb_BeschreibungDeutsch
        '
        Me.tb_BeschreibungDeutsch.Location = New System.Drawing.Point(133, 113)
        Me.tb_BeschreibungDeutsch.Name = "tb_BeschreibungDeutsch"
        Me.tb_BeschreibungDeutsch.Size = New System.Drawing.Size(108, 20)
        Me.tb_BeschreibungDeutsch.TabIndex = 18
        '
        'label_AnzahlWörter
        '
        Me.label_AnzahlWörter.AutoSize = True
        Me.label_AnzahlWörter.Location = New System.Drawing.Point(188, 161)
        Me.label_AnzahlWörter.Name = "label_AnzahlWörter"
        Me.label_AnzahlWörter.Size = New System.Drawing.Size(77, 13)
        Me.label_AnzahlWörter.TabIndex = 19
        Me.label_AnzahlWörter.Text = "Anzahl Wörter:"
        '
        'label_WortartEnglisch
        '
        Me.label_WortartEnglisch.AutoSize = True
        Me.label_WortartEnglisch.Location = New System.Drawing.Point(249, 91)
        Me.label_WortartEnglisch.Name = "label_WortartEnglisch"
        Me.label_WortartEnglisch.Size = New System.Drawing.Size(85, 13)
        Me.label_WortartEnglisch.TabIndex = 20
        Me.label_WortartEnglisch.Text = "Wortart Englisch"
        '
        'label_BeschreibungEnglisch
        '
        Me.label_BeschreibungEnglisch.AutoSize = True
        Me.label_BeschreibungEnglisch.Location = New System.Drawing.Point(249, 116)
        Me.label_BeschreibungEnglisch.Name = "label_BeschreibungEnglisch"
        Me.label_BeschreibungEnglisch.Size = New System.Drawing.Size(115, 13)
        Me.label_BeschreibungEnglisch.TabIndex = 21
        Me.label_BeschreibungEnglisch.Text = "Beschreibung Englisch"
        '
        'tb_WortartEnglisch
        '
        Me.tb_WortartEnglisch.Location = New System.Drawing.Point(370, 88)
        Me.tb_WortartEnglisch.Name = "tb_WortartEnglisch"
        Me.tb_WortartEnglisch.Size = New System.Drawing.Size(108, 20)
        Me.tb_WortartEnglisch.TabIndex = 22
        '
        'tb_BeschreibungEnglisch
        '
        Me.tb_BeschreibungEnglisch.Location = New System.Drawing.Point(370, 113)
        Me.tb_BeschreibungEnglisch.Name = "tb_BeschreibungEnglisch"
        Me.tb_BeschreibungEnglisch.Size = New System.Drawing.Size(108, 20)
        Me.tb_BeschreibungEnglisch.TabIndex = 23
        '
        'tb_AnzahlWörter
        '
        Me.tb_AnzahlWörter.Location = New System.Drawing.Point(287, 158)
        Me.tb_AnzahlWörter.Name = "tb_AnzahlWörter"
        Me.tb_AnzahlWörter.Size = New System.Drawing.Size(24, 20)
        Me.tb_AnzahlWörter.TabIndex = 24
        '
        'Form_Benutzeroberfläche
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(630, 529)
        Me.Controls.Add(Me.tb_AnzahlWörter)
        Me.Controls.Add(Me.tb_BeschreibungEnglisch)
        Me.Controls.Add(Me.tb_WortartEnglisch)
        Me.Controls.Add(Me.label_BeschreibungEnglisch)
        Me.Controls.Add(Me.label_WortartEnglisch)
        Me.Controls.Add(Me.label_AnzahlWörter)
        Me.Controls.Add(Me.tb_BeschreibungDeutsch)
        Me.Controls.Add(Me.label_BeschreibungDeutsch)
        Me.Controls.Add(Me.tb_WortartDeutsch)
        Me.Controls.Add(Me.tb_Englisch)
        Me.Controls.Add(Me.label_WortartDeutsch)
        Me.Controls.Add(Me.label_Englisch)
        Me.Controls.Add(Me.label_Deutsch)
        Me.Controls.Add(Me.rb_Deutsch)
        Me.Controls.Add(Me.rb_Englisch)
        Me.Controls.Add(Me.label_Informationen)
        Me.Controls.Add(Me.label_Wörter)
        Me.Controls.Add(Me.tb_Informationen)
        Me.Controls.Add(Me.tb_Wörter)
        Me.Controls.Add(Me.btn_Suche)
        Me.Controls.Add(Me.tb_Suchen)
        Me.Controls.Add(Me.tb_Deutsch)
        Me.Controls.Add(Me.btn_AlleAnzeigen)
        Me.Controls.Add(Me.btn_Hinzufügen)
        Me.Name = "Form_Benutzeroberfläche"
        Me.Text = "Wörterbuch"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_Hinzufügen As System.Windows.Forms.Button
    Friend WithEvents btn_AlleAnzeigen As System.Windows.Forms.Button
    Friend WithEvents tb_Deutsch As System.Windows.Forms.TextBox
    Friend WithEvents tb_Suchen As System.Windows.Forms.TextBox
    Friend WithEvents btn_Suche As System.Windows.Forms.Button
    Friend WithEvents tb_Wörter As System.Windows.Forms.TextBox
    Friend WithEvents tb_Informationen As System.Windows.Forms.TextBox
    Friend WithEvents label_Wörter As System.Windows.Forms.Label
    Friend WithEvents label_Informationen As System.Windows.Forms.Label
    Friend WithEvents rb_Englisch As System.Windows.Forms.RadioButton
    Friend WithEvents rb_Deutsch As System.Windows.Forms.RadioButton
    Friend WithEvents label_Deutsch As System.Windows.Forms.Label
    Friend WithEvents label_Englisch As System.Windows.Forms.Label
    Friend WithEvents label_WortartDeutsch As System.Windows.Forms.Label
    Friend WithEvents tb_Englisch As System.Windows.Forms.TextBox
    Friend WithEvents tb_WortartDeutsch As System.Windows.Forms.TextBox
    Friend WithEvents label_BeschreibungDeutsch As System.Windows.Forms.Label
    Friend WithEvents tb_BeschreibungDeutsch As System.Windows.Forms.TextBox
    Friend WithEvents label_AnzahlWörter As System.Windows.Forms.Label
    Friend WithEvents label_WortartEnglisch As System.Windows.Forms.Label
    Friend WithEvents label_BeschreibungEnglisch As System.Windows.Forms.Label
    Friend WithEvents tb_WortartEnglisch As System.Windows.Forms.TextBox
    Friend WithEvents tb_BeschreibungEnglisch As System.Windows.Forms.TextBox
    Friend WithEvents tb_AnzahlWörter As System.Windows.Forms.TextBox

End Class
