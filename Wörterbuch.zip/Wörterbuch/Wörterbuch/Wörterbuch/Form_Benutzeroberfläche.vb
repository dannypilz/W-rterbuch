﻿Option Strict On

Public Class Form_Benutzeroberfläche

    'erstelle ein neues Objekt der Wörterbuch-Klasse
    Dim Wörterbuch As New Wörterbuch

    'Button zum hinzufügen eines neuen Wortes zum Wörterbuch
    Private Sub btn_Add_Click(sender As System.Object, e As System.EventArgs) Handles btn_Hinzufügen.Click

        'Fehlermeldung falls nicht sämtliche TextBoxen ausgefüllt
        If tb_Deutsch.Text = "" Or tb_Englisch.Text = "" Or tb_WortartDeutsch.Text = "" Or tb_WortartEnglisch.Text = "" Or tb_BeschreibungDeutsch.Text = "" Or tb_BeschreibungEnglisch.Text = "" Then

            'Fehlermeldung je nach Sracheinstellung anpassen
            If rb_Deutsch.Checked = True Then
                MsgBox("Informationen nicht vollständig.")
            Else
                MsgBox("Information not complite.")
            End If

        Else
            'leeren der TextBoxen und ausführen der Hinzufügen-Funktion (gleichzeitiges aktualisieren der Anzahl an Wörter)
            tb_AnzahlWörter.Text = CStr(Wörterbuch.Hinzufügen(tb_Deutsch.Text, tb_Englisch.Text, tb_WortartDeutsch.Text, tb_BeschreibungDeutsch.Text, tb_WortartEnglisch.Text, tb_BeschreibungEnglisch.Text))
            tb_Deutsch.Text = ""
            tb_Englisch.Text = ""
            tb_WortartDeutsch.Text = ""
            tb_BeschreibungDeutsch.Text = ""
            tb_WortartEnglisch.Text = ""
            tb_BeschreibungEnglisch.Text = ""
        End If

    End Sub

    'Button zum anzeigen aller Wörter des Wörterbuches
    Private Sub btn_ShowAll_Click(sender As System.Object, e As System.EventArgs) Handles btn_AlleAnzeigen.Click

        'leeren der Informations-Textbox
        tb_Informationen.Text = ""

        'anpassen der Ausgabe, je nach Spracheinstellung
        If rb_Englisch.Checked = True Then
            tb_Wörter.Text = Wörterbuch.ShowAll()
        Else
            tb_Wörter.Text = Wörterbuch.AlleAnzeigen()
        End If

    End Sub

    'Button für die Such-Funktion
    Private Sub btn_Search_Click(sender As System.Object, e As System.EventArgs) Handles btn_Suche.Click

        'angepasste Ausgabe, je nach Spracheinstellung
        If rb_Englisch.Checked = True Then
            tb_Informationen.Text = Wörterbuch.Suche(tb_Suchen.Text, False)
        Else
            tb_Informationen.Text = Wörterbuch.Suche(tb_Suchen.Text, True)
        End If

    End Sub

    'Anpassung der Steuerelement Beschriftungen + Ausführen der passenden Anzeige-Funktion
    Private Sub rb_Englisch_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rb_Englisch.CheckedChanged
        Me.Text = "dictionary"
        rb_Deutsch.Text = "German"
        rb_Englisch.Text = "English"
        btn_AlleAnzeigen.Text = "show all"
        btn_Suche.Text = "search"
        btn_Hinzufügen.Text = "add"
        label_Deutsch.Text = "German"
        label_Englisch.Text = "English"
        label_WortartDeutsch.Text = "part-of-speech German"
        label_WortartEnglisch.Text = "part-of-speech English"
        label_BeschreibungDeutsch.Text = "description German"
        label_BeschreibungEnglisch.Text = "description English"
        label_AnzahlWörter.Text = "number of words:"
        label_Informationen.Text = "information:"
        label_Wörter.Text = "words:"
        tb_Wörter.Text = Wörterbuch.ShowAll()
        tb_Informationen.Text = ""
    End Sub

    'Anpassung der Steuerelement Beschriftungen + Ausführen der passenden Anzeige-Funktion
    Private Sub rb_Deutsch_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rb_Deutsch.CheckedChanged
        Me.Text = "Wörterbuch"
        rb_Deutsch.Text = "Deutsch"
        rb_Englisch.Text = "Englisch"
        btn_AlleAnzeigen.Text = "Alle anzeigen"
        btn_Suche.Text = "Suche"
        btn_Hinzufügen.Text = "Hinzufügen"
        label_Deutsch.Text = "Deutsch"
        label_Englisch.Text = "Englisch"
        label_WortartDeutsch.Text = "Wortart Deutsch"
        label_WortartEnglisch.Text = "Wortart Englisch"
        label_BeschreibungDeutsch.Text = "Beschreibung Deutsch"
        label_BeschreibungEnglisch.Text = "Beschreibung Englisch"
        label_AnzahlWörter.Text = "Anzahl Wörter:"
        label_Informationen.Text = "Informationen:"
        label_Wörter.Text = "Wörter:"
        tb_Wörter.Text = Wörterbuch.AlleAnzeigen()
        tb_Informationen.Text = ""
    End Sub

    'Load Funktion aktualiseiren der Anzahl an Wörter
    Private Sub Form_Benutzeroberfläche_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Anzahl an Wörter aktualiesieren beim Start
        tb_AnzahlWörter.Text = CStr(Wörterbuch.AnzahlWörter)

    End Sub

End Class
