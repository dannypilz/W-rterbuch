﻿Option Strict On

Public Class Wort

    'Attribute der Wort-Klasse
    Public Deutsch As String
    Public English As String
    Public WortartDeutsch As String
    Public BeschreibungDeutsch As String
    Public WortartEnglisch As String
    Public BeschreibungEnglisch As String

    'Konstruktor der Wort-Klasse
    Public Sub New(deutsch As String, english As String, wortartdeutsch As String, beschreibungdeutsch As String, wortartenglisch As String, beschreibungenglisch As String)
        Me.Deutsch = deutsch
        Me.English = english
        Me.WortartDeutsch = wortartdeutsch
        Me.BeschreibungDeutsch = beschreibungdeutsch
        Me.WortartEnglisch = wortartenglisch
        Me.BeschreibungEnglisch = beschreibungenglisch
    End Sub

    'Funktion die den Informationstext erstellt und zurück gibt (Deutsch)
    Public Function Informationen() As String

        Dim Informationstext As String = "Deutsch: " + Me.Deutsch + vbCrLf + "Englisch: " + Me.English + vbCrLf + "Wortart: " + Me.WortartDeutsch + vbCrLf + "Beschreibung: " + Me.BeschreibungDeutsch + vbCrLf
        Return Informationstext

    End Function

    'Funktion die den Informationstext erstellt und zurück gibt (Englisch)
    Public Function information() As String

        Dim Informationstext As String = "English: " + Me.English + vbCrLf + "German: " + Me.Deutsch + vbCrLf + "part-of-speech: " + Me.WortartEnglisch + vbCrLf + "description: " + Me.BeschreibungEnglisch + vbCrLf
        Return Informationstext

    End Function

End Class
