﻿Option Strict On

Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Wörterbuch

    'Attribute der Wörterbuch-Klasse
    Public Wörter As List(Of Wort)
    Public AnzahlWörter As Integer

    'Konstruktor der Wörterbuch-Klasse
    Public Sub New()

        ''neue Wörter Liste erstellen
        'Me.Wörter = New List(Of Wort)

        ''Ohne Speicherung in Excel Tabelle
        ''die 4 vorgegebenen Objekte hinzufügen
        'Dim Hund As New Wort("Hund", "dog", "Nomen", "Ein fleischfressendes Haustier das mit dem Wolf und dem Fuchs verwandt ist.", "noun", "A domestic, meat-eating animal related to the wolf and fox.")
        'Wörter.Add(Hund)
        'Dim sehen As New Wort("sehen", "see", "Verb", "Mit den Augen wahrnehmen.", "verb", "To perceive with the eyes.")
        'Wörter.Add(sehen)
        'Dim heiß As New Wort("heiß", "hot", "Adjektiv", "Sehr warm.", "adjective", "Very warm.")
        'Wörter.Add(heiß)
        'Dim Baum As New Wort("Baum", "tree", "Nomen", "Die größte Art von Pflanzen, mit einem dicken, festen, hölzernen Stamm.", "noun", "The largest kind of plant, with a thick, firm, wooden stem.")
        'Wörter.Add(Baum)

        ''Anzahl Wörter zuweisen
        'Me.AnzahlWörter = 4

        'Mit Speicherung in Excel Tabelle
        'neue Wörter Liste erstellen
        Me.Wörter = New List(Of Wort)

        'Excel Application einbinden
        Dim app As Excel.Application = New Excel.Application
        Dim book As Excel.Workbook = app.Workbooks.Open(CurDir() & "\Tabelle")
        Dim sheet As Excel.Worksheet = CType(book.Worksheets(1), Excel.Worksheet)
        Dim Zeile As Integer = 2

        'suchen, welche die letzte beschriebene Zeile ist (in Spalte 1) und Lade alle Wörter in das Wörterbuch
        While Not (CStr(CType(sheet.Cells(Zeile, 1), Excel.Range).Value) = "")
            Dim Deutsch As String = CStr(CType(sheet.Cells(Zeile, 1), Excel.Range).Value)
            Dim Englisch As String = CStr(CType(sheet.Cells(Zeile, 2), Excel.Range).Value)
            Dim WortartDeutsch As String = CStr(CType(sheet.Cells(Zeile, 3), Excel.Range).Value)
            Dim BezeichnungDeutsch As String = CStr(CType(sheet.Cells(Zeile, 4), Excel.Range).Value)
            Dim WortartEnglisch As String = CStr(CType(sheet.Cells(Zeile, 5), Excel.Range).Value)
            Dim BezeichnungEnglisch As String = CStr(CType(sheet.Cells(Zeile, 6), Excel.Range).Value)
            Dim Wort As New Wort(Deutsch, Englisch, WortartDeutsch, BezeichnungDeutsch, WortartEnglisch, BezeichnungEnglisch)
            Wörter.Add(Wort)
            Zeile += 1
        End While


        'Anzahl Wörter zuweisen
        Me.AnzahlWörter = Wörter.Count

        'schließe Excel-Verbindung
        app.Quit()
        app = Nothing
        GC.Collect()

    End Sub

    'Funktion zum erstellen des Srings um alle Wörter des Wörterbuches anzuzeigen (Deutsch)
    Public Function ShowAll() As String
        Dim Text As String = ""

        'Alle Wörter durchgehen und zur auflistung hinzufügen
        For Each Wort In Me.Wörter
            Text += Wort.English + " - " + Wort.Deutsch + vbCrLf
        Next Wort

        Return Text
    End Function

    'Funktion zum erstellen des Srings um alle Wörter des Wörterbuches anzuzeigen (Englisch)
    Public Function AlleAnzeigen() As String
        Dim Text As String = ""

        'Alle Wörter durchgehen und zur auflistung hinzufügen
        For Each Wort In Me.Wörter
            Text += Wort.Deutsch + " - " + Wort.English + vbCrLf
        Next Wort

        Return Text
    End Function

    'Funktion zum hinzufügen neuer Wörter, zur Liste und gleichzeitiges aktualisieren des "Anzahl an Wörter"-Attributs
    Public Function Hinzufügen(Deutsch As String, Englisch As String, WortartDeutsch As String, BezeichnungDeutsch As String, WortartEnglisch As String, BezeichnungEnglisch As String) As Integer

        'Hinzufügen ohne speicherung in Exceel
        'Dim Wort As New Wort(Deutsch, Englisch, WortartDeutsch, BezeichnungDeutsch, WortartEnglisch, BezeichnungEnglisch)
        'Me.Wörter.Add(Wort)
        'Me.AnzahlWörter += 1


        'Hinzufügen mit speicherung in Excel
        Dim Wort As New Wort(Deutsch, Englisch, WortartDeutsch, BezeichnungDeutsch, WortartEnglisch, BezeichnungEnglisch)
        Me.Wörter.Add(Wort)
        Me.AnzahlWörter += 1

        'Excel einbinden
        Dim app As Excel.Application = New Excel.Application
        Dim book As Excel.Workbook = app.Workbooks.Open(CurDir() & "\Tabelle")
        Dim sheet As Excel.Worksheet = CType(book.Worksheets(1), Excel.Worksheet)
        Dim Zeile As Integer = 1

        '1. Spalte durch gehen, bis eine leer
        While Not (CStr(CType(sheet.Cells(Zeile, 1), Excel.Range).Value) = "")
            Zeile += 1
        End While

        'Wort speichern
        CType(sheet.Cells(Zeile, 1), Excel.Range).Value = Deutsch
        CType(sheet.Cells(Zeile, 2), Excel.Range).Value = Englisch
        CType(sheet.Cells(Zeile, 3), Excel.Range).Value = WortartDeutsch
        CType(sheet.Cells(Zeile, 4), Excel.Range).Value = BezeichnungDeutsch
        CType(sheet.Cells(Zeile, 5), Excel.Range).Value = WortartEnglisch
        CType(sheet.Cells(Zeile, 6), Excel.Range).Value = BezeichnungEnglisch

        'Speichern in Excel Datei (ohne SaveFileDialog) + Schließen von Excel
        app.DisplayAlerts = False
        book.SaveAs(CurDir() & "\Tabelle", ConflictResolution:="xlLocalSessionChanges")
        book.Saved = True
        book.Close(SaveChanges:=False)
        app.DisplayAlerts = True
        app.Quit()
        app = Nothing
        GC.Collect()

        'Anzahl Wörter zurückgeben
        Return Me.AnzahlWörter
    End Function

    'Such-Funktion mit aufruf der Informationsfunktion
    Public Function Suche(Suchwort As String, deutsch As Boolean) As String

        'leeren String generieren
        Dim Text As String = ""

        'Alle Wörter des Wörterbuches durchgehen und schauen, ob das gesuchte Wort endwerder dem englischen oder dem deutschen Wort entspricht
        For Each Wort In Me.Wörter
            If Suchwort = Wort.Deutsch Or Suchwort = Wort.English Then

                'Variation des Informationstextes, je nach Spracheinstellung
                If deutsch Then
                    Text = Wort.Informationen
                Else
                    Text = Wort.information
                End If

            End If
        Next Wort

        'Falls Wort nicht in der Liste Ausgabe eines Fehler Textes
        If Text = "" Then

            'Variation des Fehlertextes, je nach Spracheinstellung
            If deutsch Then
                MsgBox("Nicht gefunden.")
                Return Text
            Else
                MsgBox("Not found.")
                Return Text
            End If

        Else
            Return Text
        End If

    End Function

End Class
